TONAL — addendum to letter 32990 dated 28.09.2026
AO GK ELEKTROSHCHIT - TM SAMARA

Covering letter is sent separately (on TONAL letterhead).
This ZIP contains new Rem Color documents only (attachments 1-11 of the addendum).

64  TDS primer Rem-Pox 0607 HS 2K dated 03.03.2026
65  TDS enamel Rem-Pur 1604 2K dated 03.03.2026, mix 100:12
66  Rem Color letter 29.09.2026 — technical parameters
67  Rem Color letter 23.09.2026 — hardener shelf life
68-71  SDS on Rem Color letterhead (primer, enamel, EP1 H5, PU1 M4)
72  Extract from TU BY 101558453.006-2005
73  Appendix 1 stamped by Rem Color
74  BNTU protocol 1834 dated 04.08.2025

Does not replace NSS / adhesion GOST 31149-32299 of the 0607+1604 system for 2024-2026.
