TONAL — attachments pack TZ 23/26 ORNP
AO GK ELEKTROSHCHIT - TM SAMARA

Covering letter is sent separately (outgoing No. 32990 dated 28.09.2026).
This ZIP contains attachments 1-63 only.

Unpack with Explorer, 7-Zip or WinRAR.
Filenames are Latin on purpose so Windows does not rename them.

02_apps_01-06             attachments 1-6
03_apps_07-19             attachments 7-17, 19
04_apps_18-42             attachments 18, 20-42
06_R-4                    attachments 43-45 (Neftekhimik R-4)
07_extra_capabilities     attachments 46-63 (beyond TZ)

Attachment numbers match the list in the covering letter.
